# FERBE SITE BASELINE — 27 July 2026

**Baseline ID:** `FERBE-SITE-BASELINE-20260727`
**Files:** 28 (23 HTML + 2 assets + 2 Worker + 1 XLSX + manifest)
**Total size:** 1,428,019 bytes

This is a verified, working snapshot. Every file is checksummed in `MANIFEST.json`.

---

## What this baseline contains

### Marketing site — `ferbe-site/` (25 files)

| Group | Pages |
|---|---|
| Core | index, features, ai, pricing, customers, about, contact |
| Content | blog, iso-27001-guide, checklist, help + 6 blog articles |
| Utility | partners, status |
| Legal | privacy, terms, refund, cookies |
| Assets | logo.svg, iso-27001-checklist.pdf |

### Report email API — `ferbe-worker/` (2 files)
`worker.js` and `wrangler.toml` — the Cloudflare Worker that emails assessment reports via Resend.

### Downloadable checklist — `ferbe-iso27001-checklist.xlsx`
10-tab Excel assessment workbook. Not currently linked from the site (superseded by the interactive assessment) — retained for reference.

---

## Verified state at baseline

- All 23 pages pass HTML validation (no unclosed or mismatched tags)
- All inline JavaScript passes `node --check`
- Zero broken internal links across the site
- Zero internal form codes (`FRM-xx`) exposed in public copy
- Pricing consistent across all pages: Starter RM239 / Growth RM639 / Professional RM1,599 (annual)
- Assessment tool tested end-to-end: 33 questions → PDF generation → Worker → Resend → inbox

---

## Rollback — full site

If a future change breaks the live site:

```bash
cd ~/Documents/ferbe-site          # your local clone of ferbeai/ferbe-site
git log --oneline                  # find the commit before the bad change
git revert <commit-hash>           # safest: creates a new commit undoing it
git push
```

Cloudflare Pages redeploys in about 30 seconds.

**If Git history is not usable**, restore from this baseline directly:

1. Copy all files from `ferbe-baseline/ferbe-site/` into your local repo folder, overwriting
2. `git add . && git commit -m "Restore baseline 20260727" && git push`

---

## Rollback — single page

```bash
cd ~/Documents/ferbe-site
git checkout <good-commit-hash> -- checklist.html
git commit -m "Restore checklist.html to known-good state"
git push
```

Or simply copy the one file from `ferbe-baseline/ferbe-site/` and commit it.

---

## Rollback — Worker

```bash
cd ~/Documents/ferbe-worker
npx wrangler deployments list        # shows every deployed version
npx wrangler rollback <version-id>   # instant rollback, no redeploy needed
```

Cloudflare keeps prior Worker versions indefinitely. Rollback takes effect immediately.

To restore the source files, copy from `ferbe-baseline/ferbe-worker/` and run `npx wrangler deploy`.

**Note:** The `RESEND_API_KEY` secret is stored in Cloudflare, not in these files. Rollback does not affect it.

---

## Verifying integrity

To confirm files have not been altered since baseline:

```bash
cd ferbe-baseline
python3 - <<'EOF'
import hashlib, json, os
m = json.load(open('MANIFEST.json'))
bad = []
for rel, meta in m['files'].items():
    if rel == 'MANIFEST.json': continue
    if not os.path.exists(rel):
        bad.append((rel, 'MISSING')); continue
    h = hashlib.sha256(open(rel,'rb').read()).hexdigest()
    if h != meta['sha256']:
        bad.append((rel, 'CHANGED'))
print('\n'.join(f'{s}: {f}' for f, s in bad) if bad else 'All files match baseline.')
EOF
```

---

## Before overwriting the live repo

`ferbeai/ferbe-site` may contain files not in this baseline — for example `robots.txt`, `sitemap.xml`, `favicon.ico`, `_headers`, `_redirects`, or a Pages `wrangler.toml`.

**Upload files individually rather than clearing the repo.** Deleting those would break SEO, caching headers, or redirects.

---

## Rules

- **Never overwrite this baseline folder.** Create a new dated baseline for future snapshots.
- Take a new baseline after any milestone where the site is verified working.
- Keep the manifest with the files — it is the only way to prove integrity later.
