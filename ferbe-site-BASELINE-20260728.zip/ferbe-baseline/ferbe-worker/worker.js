/**
 * Ferbe — Assessment Report Email Worker
 * Cloudflare Worker · sends ISO 27001:2022 assessment report PDF via Resend
 *
 * SETUP:
 *   1. Create Resend account → https://resend.com (free: 3,000 emails/month)
 *   2. Verify ferbe.ai domain in Resend (add DNS records in Cloudflare)
 *   3. Add secret:  npx wrangler secret put RESEND_API_KEY
 *   4. Deploy:      npx wrangler deploy
 *
 * ENDPOINT:  POST /api/send-report
 * BODY:      { email, pdfBase64, score, rating, reportId, gapCount }
 */

const ALLOWED_ORIGINS = [
  'https://ferbe.ai',
  'https://www.ferbe.ai',
  'http://localhost:8788',
];

function corsHeaders(origin) {
  const allow = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allow,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400',
  };
}

function json(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders(origin) },
  });
}

function isValidEmail(email) {
  return typeof email === 'string' &&
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) &&
    email.length < 255;
}

function buildEmailHtml({ score, rating, reportId, gapCount, date }) {
  const ratingColor =
    rating === 'Ready' ? '#16A34A' :
    rating === 'Partially Ready' ? '#B45309' : '#DC2626';

  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#F8FAFC;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F8FAFC;padding:32px 16px;">
<tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#FFFFFF;border-radius:16px;overflow:hidden;border:1px solid #E2E8F0;">

  <tr><td style="background:#0F172A;padding:28px 32px;">
    <table role="presentation" cellpadding="0" cellspacing="0"><tr>
      <td style="padding-right:14px;">
        <div style="width:44px;height:44px;border-radius:10px;background:#0D7C66;text-align:center;line-height:44px;font-size:20px;font-weight:800;color:#D4FF00;">F</div>
      </td>
      <td>
        <div style="font-size:18px;font-weight:800;color:#FFFFFF;">Ferbe</div>
        <div style="font-size:12px;color:rgba(255,255,255,0.5);margin-top:2px;">ISO 27001:2022 ISMS Platform</div>
      </td>
    </tr></table>
  </td></tr>

  <tr><td style="padding:32px;">
    <h1 style="margin:0 0 12px;font-size:22px;font-weight:800;color:#0F172A;line-height:1.3;">Your ISO 27001:2022 Readiness Report</h1>
    <p style="margin:0 0 24px;font-size:15px;color:#475569;line-height:1.7;">
      Thank you for completing the Ferbe ISO 27001:2022 dipstick assessment.
      Your full report is attached as a PDF.
    </p>

    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;margin-bottom:24px;">
      <tr>
        <td style="padding:20px 24px;" align="center">
          <div style="font-size:40px;font-weight:800;color:${ratingColor};line-height:1;">${score}%</div>
          <div style="font-size:11px;color:#94A3B8;margin-top:4px;text-transform:uppercase;letter-spacing:0.06em;">Overall Readiness Score</div>
          <div style="display:inline-block;margin-top:12px;padding:5px 16px;border-radius:100px;background:${ratingColor}18;color:${ratingColor};font-size:13px;font-weight:700;">${rating}</div>
        </td>
      </tr>
    </table>

    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
      <tr>
        <td style="padding:12px 16px;background:#FFFBEB;border-left:3px solid #B45309;border-radius:0 8px 8px 0;">
          <div style="font-size:13px;color:#78350F;line-height:1.6;">
            <strong>${gapCount} gap${gapCount === 1 ? '' : 's'} identified.</strong>
            The attached PDF includes detailed remediation guidance for each one —
            the specific ISO 27001:2022 requirement, why it matters, and how to close it.
          </div>
        </td>
      </tr>
    </table>

    <p style="margin:0 0 8px;font-size:14px;font-weight:700;color:#0F172A;">What's in your report</p>
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:28px;">
      ${[
        'Overall readiness score and certification rating',
        'Clause-by-clause breakdown across all 7 mandatory clauses',
        'Complete gap list with question references',
        'Detailed remediation guidance for every gap',
      ].map(item => `<tr><td style="padding:5px 0;font-size:14px;color:#475569;line-height:1.6;">
        <span style="color:#0D7C66;font-weight:700;margin-right:8px;">&#10003;</span>${item}</td></tr>`).join('')}
    </table>

    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F0FDF4;border:1px solid rgba(13,124,102,0.2);border-radius:12px;margin-bottom:24px;">
      <tr><td style="padding:20px 24px;">
        <div style="font-size:15px;font-weight:800;color:#0F172A;margin-bottom:8px;">Close every gap. Get certified faster.</div>
        <div style="font-size:13px;color:#475569;line-height:1.7;margin-bottom:16px;">
          Ferbe structures every ISO 27001:2022 workflow automatically — 74 pre-structured documents,
          a 98-control Annex A audit checklist, NC management, Management Review with FRM-15 generation,
          and evidence management with a full audit trail. Every gap in your report maps to a Ferbe module.
        </div>
        <a href="https://ferbe.ai" style="display:inline-block;padding:12px 24px;background:#0D7C66;color:#FFFFFF;text-decoration:none;border-radius:8px;font-size:14px;font-weight:700;">Start your free 14-day trial</a>
      </td></tr>
    </table>

    <p style="margin:0;font-size:12px;color:#94A3B8;line-height:1.6;">
      Report ID: ${reportId} &middot; Generated ${date}
    </p>
  </td></tr>

  <tr><td style="padding:20px 32px;background:#F8FAFC;border-top:1px solid #E2E8F0;">
    <p style="margin:0 0 10px;font-size:11px;color:#94A3B8;line-height:1.6;">
      <strong style="color:#64748B;">Disclaimer:</strong> This assessment is a self-reported dipstick evaluation
      and does not constitute a formal ISO 27001:2022 audit, certification, or legal opinion. Results reflect
      your own assessment and have not been independently verified. For formal certification, engage an
      accredited certification body such as BSI, SGS, Bureau Veritas, or SIRIM QAS.
    </p>
    <p style="margin:0;font-size:11px;color:#94A3B8;line-height:1.6;">
      &copy; 2026 Energized Empire Sdn. Bhd. &middot; Ferbe &middot;
      <a href="https://ferbe.ai" style="color:#0D7C66;text-decoration:none;">ferbe.ai</a><br>
      Your assessment answers were processed locally in your browser and are not stored on Ferbe servers.
      Governed by Malaysia's Personal Data Protection Act (PDPA) 2010.
    </p>
  </td></tr>

</table>
</td></tr>
</table>
</body>
</html>`;
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders(origin) });
    }

    const url = new URL(request.url);
    if (url.pathname !== '/api/send-report') {
      return json({ error: 'Not found' }, 404, origin);
    }
    if (request.method !== 'POST') {
      return json({ error: 'Method not allowed' }, 405, origin);
    }

    let payload;
    try {
      payload = await request.json();
    } catch {
      return json({ error: 'Invalid JSON body' }, 400, origin);
    }

    const { email, pdfBase64, score, rating, reportId, gapCount } = payload || {};

    if (!isValidEmail(email)) {
      return json({ error: 'A valid email address is required' }, 400, origin);
    }
    if (typeof pdfBase64 !== 'string' || pdfBase64.length < 100) {
      return json({ error: 'Report PDF is missing or malformed' }, 400, origin);
    }
    if (pdfBase64.length > 8_000_000) {
      return json({ error: 'Report PDF exceeds size limit' }, 413, origin);
    }
    if (!env.RESEND_API_KEY) {
      return json({ error: 'Email service is not configured' }, 500, origin);
    }

    const safeScore  = Number.isFinite(+score) ? Math.round(+score) : 0;
    const safeRating = ['Ready', 'Partially Ready', 'Not Ready'].includes(rating) ? rating : 'Not Ready';
    const safeId     = typeof reportId === 'string' ? reportId.slice(0, 32) : 'FRB-UNKNOWN';
    const safeGaps   = Number.isFinite(+gapCount) ? Math.max(0, Math.round(+gapCount)) : 0;
    const date       = new Date().toLocaleDateString('en-GB', {
      day: '2-digit', month: 'long', year: 'numeric',
    });

    const resendRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${env.RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Ferbe <reports@ferbe.ai>',
        reply_to: 'hello@ferbe.ai',
        to: [email],
        bcc: ['hello@ferbe.ai'],
        subject: `Your ISO 27001:2022 Readiness Report — ${safeScore}% (${safeRating})`,
        html: buildEmailHtml({
          score: safeScore, rating: safeRating,
          reportId: safeId, gapCount: safeGaps, date,
        }),
        attachments: [{
          filename: `Ferbe-ISO27001-Readiness-Report-${safeId}.pdf`,
          content: pdfBase64,
        }],
      }),
    });

    if (!resendRes.ok) {
      const detail = await resendRes.text();
      console.error('Resend error', resendRes.status, detail);
      return json({ error: 'Could not send the report. Please try again.' }, 502, origin);
    }

    const result = await resendRes.json();
    return json({ ok: true, id: result.id, reportId: safeId }, 200, origin);
  },
};
